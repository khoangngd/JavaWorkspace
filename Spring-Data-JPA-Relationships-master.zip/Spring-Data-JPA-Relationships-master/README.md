# Spring-Data-JPA-Relationships

This is a repository to support a [YouTube Tutorial Video](https://youtu.be/f5bdUjEIbrg) I was working on.
