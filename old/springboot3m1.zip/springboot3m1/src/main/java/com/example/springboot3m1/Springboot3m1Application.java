package com.example.springboot3m1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3m1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3m1Application.class, args);
	}

}
