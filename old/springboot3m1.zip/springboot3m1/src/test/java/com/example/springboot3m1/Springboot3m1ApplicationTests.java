package com.example.springboot3m1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot3m1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
