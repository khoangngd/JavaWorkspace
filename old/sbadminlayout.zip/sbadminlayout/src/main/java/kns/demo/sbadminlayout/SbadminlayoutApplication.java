package kns.demo.sbadminlayout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbadminlayoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbadminlayoutApplication.class, args);
	}

}
