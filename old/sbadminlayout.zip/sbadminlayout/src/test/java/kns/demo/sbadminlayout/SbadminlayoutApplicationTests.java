package kns.demo.sbadminlayout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbadminlayoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
