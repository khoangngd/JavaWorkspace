package tls.demo.aml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
