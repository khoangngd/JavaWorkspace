package vn.com.shinhanlifevn.apps.aml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
