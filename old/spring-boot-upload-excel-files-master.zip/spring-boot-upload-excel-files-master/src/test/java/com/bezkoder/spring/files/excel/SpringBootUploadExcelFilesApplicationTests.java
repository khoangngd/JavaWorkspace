package com.bezkoder.spring.files.excel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUploadExcelFilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
