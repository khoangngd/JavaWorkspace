package com.example.springboot3war;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3warApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3warApplication.class, args);
	}

}
