package com.example.springboot3war;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot3warApplicationTests {

	@Test
	void contextLoads() {
	}

}
