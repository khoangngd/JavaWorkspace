package com.techgeeknext.repository.company;

import com.techgeeknext.entities.company.Company;
import org.springframework.data.repository.CrudRepository;

public interface CompanyRepository extends CrudRepository<Company, Integer> {

}
