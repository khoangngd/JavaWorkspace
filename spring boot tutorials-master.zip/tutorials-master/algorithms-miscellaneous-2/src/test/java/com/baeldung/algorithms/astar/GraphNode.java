package com.baeldung.algorithms.astar;

public interface GraphNode {
    String getId();
}
