## Animal Sniffer Maven Plugin

This module contains articles about the Animal Sniffer Maven Plugin

### Relevant articles:

[Introduction to Animal Sniffer Maven Plugin](https://www.baeldung.com/maven-animal-sniffer)
